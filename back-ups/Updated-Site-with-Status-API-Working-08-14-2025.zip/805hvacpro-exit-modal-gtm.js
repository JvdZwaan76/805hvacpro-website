<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>805 HVAC Pro - Exit Intent Modal</title>
  <style>
    /* Modal Styles - Enterprise Design System */
    .hvac-exit-modal {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(15, 23, 42, 0.8);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      visibility: hidden;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      padding: 1rem;
    }

    .hvac-exit-modal.active {
      opacity: 1;
      visibility: visible;
    }

    .hvac-modal-content {
      background: white;
      border-radius: 1.5rem;
      box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
      max-width: 500px;
      width: 100%;
      position: relative;
      transform: translateY(20px) scale(0.95);
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      overflow: hidden;
      border: 1px solid #e5e7eb;
    }

    .hvac-exit-modal.active .hvac-modal-content {
      transform: translateY(0) scale(1);
    }

    /* Header with gradient */
    .hvac-modal-header {
      background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #2563eb 100%);
      padding: 2rem 2rem 1.5rem;
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .hvac-modal-header::before {
      content: '';
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.1) 0%, transparent 60%);
      pointer-events: none;
    }

    .hvac-modal-icon {
      width: 64px;
      height: 64px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      border-radius: 50%;
      margin: 0 auto 1rem;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 25px rgba(251, 191, 36, 0.3);
      position: relative;
      z-index: 10;
    }

    .hvac-modal-icon svg {
      width: 32px;
      height: 32px;
      color: #1f2937;
    }

    .hvac-modal-title {
      font-family: 'Playfair Display', Georgia, serif;
      font-size: 1.75rem;
      font-weight: 600;
      color: white;
      margin: 0 0 0.5rem;
      position: relative;
      z-index: 10;
    }

    .hvac-modal-subtitle {
      font-family: 'Inter', sans-serif;
      font-size: 1rem;
      color: rgba(255, 255, 255, 0.9);
      margin: 0;
      position: relative;
      z-index: 10;
    }

    /* Body content */
    .hvac-modal-body {
      padding: 2rem;
      text-align: center;
    }

    .hvac-modal-message {
      font-family: 'Inter', sans-serif;
      font-size: 1.125rem;
      color: #374151;
      margin-bottom: 1.5rem;
      line-height: 1.6;
    }

    .hvac-modal-features {
      margin-bottom: 2rem;
    }

    .hvac-modal-feature {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.75rem;
      margin-bottom: 0.75rem;
      font-family: 'Inter', sans-serif;
      font-size: 0.875rem;
      color: #6b7280;
    }

    .hvac-modal-feature:last-child {
      margin-bottom: 0;
    }

    .hvac-modal-feature svg {
      width: 16px;
      height: 16px;
      color: #10b981;
      flex-shrink: 0;
    }

    /* CTA Buttons */
    .hvac-modal-actions {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }

    .hvac-modal-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      font-family: 'Inter', sans-serif;
      font-weight: 600;
      font-size: 0.9rem;
      text-decoration: none;
      border: none;
      border-radius: 0.75rem;
      cursor: pointer;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
      padding: 0.875rem 1.5rem;
      min-height: 48px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .hvac-modal-btn::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transition: left 0.5s;
    }

    .hvac-modal-btn:hover::before {
      left: 100%;
    }

    .hvac-modal-btn-primary {
      background: linear-gradient(135deg, #1e40af, #1d4ed8);
      color: white;
      box-shadow: 0 4px 12px rgba(30, 64, 175, 0.3);
    }

    .hvac-modal-btn-primary:hover {
      background: linear-gradient(135deg, #1d4ed8, #1e3a8a);
      box-shadow: 0 6px 20px rgba(30, 64, 175, 0.4);
      transform: translateY(-2px);
    }

    .hvac-modal-btn-secondary {
      background: linear-gradient(135deg, #f59e0b, #d97706);
      color: #1f2937;
      box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
    }

    .hvac-modal-btn-secondary:hover {
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      box-shadow: 0 6px 20px rgba(245, 158, 11, 0.4);
      transform: translateY(-2px);
    }

    .hvac-modal-btn svg {
      width: 18px;
      height: 18px;
    }

    /* Close button */
    .hvac-modal-close {
      position: absolute;
      top: 1rem;
      right: 1rem;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.3s ease;
      z-index: 20;
    }

    .hvac-modal-close:hover {
      background: rgba(255, 255, 255, 0.3);
      transform: scale(1.1);
    }

    .hvac-modal-close svg {
      width: 20px;
      height: 20px;
      color: white;
    }

    /* No thanks link */
    .hvac-modal-dismiss {
      margin-top: 1rem;
      font-family: 'Inter', sans-serif;
      font-size: 0.875rem;
      color: #6b7280;
      text-decoration: none;
      transition: color 0.3s ease;
    }

    .hvac-modal-dismiss:hover {
      color: #374151;
      text-decoration: underline;
    }

    /* Mobile responsiveness */
    @media (max-width: 640px) {
      .hvac-exit-modal {
        padding: 0.5rem;
      }

      .hvac-modal-content {
        max-width: 100%;
        margin: 0.5rem;
      }

      .hvac-modal-header {
        padding: 1.5rem 1.5rem 1rem;
      }

      .hvac-modal-body {
        padding: 1.5rem;
      }

      .hvac-modal-title {
        font-size: 1.5rem;
      }

      .hvac-modal-subtitle {
        font-size: 0.9rem;
      }

      .hvac-modal-message {
        font-size: 1rem;
      }

      .hvac-modal-actions {
        gap: 0.5rem;
      }

      .hvac-modal-btn {
        padding: 0.75rem 1.25rem;
        font-size: 0.85rem;
      }
    }

    /* Accessibility */
    @media (prefers-reduced-motion: reduce) {
      .hvac-exit-modal,
      .hvac-modal-content,
      .hvac-modal-btn {
        transition: none;
      }
    }

    /* High contrast mode */
    @media (prefers-contrast: high) {
      .hvac-modal-content {
        border: 2px solid #000;
      }
      
      .hvac-modal-btn {
        border: 2px solid currentColor;
      }
    }
  </style>
</head>
<body>

<!-- Exit Intent Modal HTML -->
<div id="hvacExitModal" class="hvac-exit-modal" role="dialog" aria-labelledby="modal-title" aria-describedby="modal-description" aria-hidden="true">
  <div class="hvac-modal-content">
    <!-- Close Button -->
    <button class="hvac-modal-close" onclick="closeHVACModal()" aria-label="Close modal">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
      </svg>
    </button>

    <!-- Header -->
    <div class="hvac-modal-header">
      <div class="hvac-modal-icon">
        <svg fill="currentColor" viewBox="0 0 24 24">
          <path d="M2 12C2 6.48 6.48 2 12 2s10 4.48 10 10-4.48 10-10 10S2 17.52 2 12zm4.64-1.96l3.54 3.54c.78.78 2.05.78 2.83 0l7.07-7.07c.78-.78.78-2.05 0-2.83-.78-.78-2.05-.78-2.83 0L12 9.93 6.75 4.68c-.78-.78-2.05-.78-2.83 0-.78.78-.78 2.05 0 2.83l2.72 2.72z"/>
        </svg>
      </div>
      <h2 id="modal-title" class="hvac-modal-title">Before You Go...</h2>
      <p class="hvac-modal-subtitle">Don't let HVAC problems leave you in the cold!</p>
    </div>

    <!-- Body -->
    <div class="hvac-modal-body">
      <p id="modal-description" class="hvac-modal-message">
        Get your <strong>FREE HVAC consultation</strong> from Thousand Oaks' most trusted HVAC professionals.
      </p>

      <div class="hvac-modal-features">
        <div class="hvac-modal-feature">
          <svg fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span>24/7 Emergency Service Available</span>
        </div>
        <div class="hvac-modal-feature">
          <svg fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span>Licensed, Bonded & Insured</span>
        </div>
        <div class="hvac-modal-feature">
          <svg fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span>Same-Day Service in 805 Area</span>
        </div>
      </div>

      <!-- CTA Buttons -->
      <div class="hvac-modal-actions">
        <a href="tel:8056688329" class="hvac-modal-btn hvac-modal-btn-secondary" onclick="trackModalPhoneClick()">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
          </svg>
          Call Now: (805) 668-8329
        </a>
        <a href="/contact.html" class="hvac-modal-btn hvac-modal-btn-primary" onclick="trackModalContactClick()">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
          </svg>
          Get Free Estimate
        </a>
      </div>

      <a href="#" class="hvac-modal-dismiss" onclick="closeHVACModal()">
        No thanks, I'll freeze later
      </a>
    </div>
  </div>
</div>

<script>
// Exit Intent Modal JavaScript for GTM Integration
(function() {
  'use strict';

  // Configuration
  const config = {
    exitIntent: true,
    timeDelay: 30000,        // 30 seconds
    scrollPercentage: 70,    // 70% scroll
    sessionLimit: 1,         // Once per session
    cookieName: 'hvac_exit_modal_shown',
    cookieExpiry: 7,         // 7 days
    debugMode: false
  };

  // State tracking
  let modalShown = false;
  let exitIntentTriggered = false;
  let timeDelayTriggered = false;
  let scrollTriggered = false;

  // Utility functions
  function setCookie(name, value, days) {
    const expires = new Date();
    expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
    document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
  }

  function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
  }

  function log(message) {
    if (config.debugMode) {
      console.log('[HVAC Exit Modal]', message);
    }
  }

  // Check if modal should be shown
  function shouldShowModal() {
    if (modalShown) return false;
    
    // Check cookie
    const cookieValue = getCookie(config.cookieName);
    if (cookieValue) {
      log('Modal already shown in this session');
      return false;
    }

    // Check if on contact page (don't show modal on contact page)
    if (window.location.pathname.includes('contact')) {
      log('On contact page, skipping modal');
      return false;
    }

    return true;
  }

  // Show modal function
  function showModal(trigger) {
    if (!shouldShowModal()) return;

    modalShown = true;
    setCookie(config.cookieName, 'true', config.cookieExpiry);

    const modal = document.getElementById('hvacExitModal');
    if (modal) {
      modal.classList.add('active');
      modal.setAttribute('aria-hidden', 'false');
      
      // Focus management for accessibility
      const firstButton = modal.querySelector('.hvac-modal-btn');
      if (firstButton) {
        firstButton.focus();
      }

      // Track with GTM
      if (typeof dataLayer !== 'undefined') {
        dataLayer.push({
          event: 'exit_intent_modal_shown',
          modal_trigger: trigger,
          page_url: window.location.href
        });
      }

      log(`Modal shown via ${trigger}`);
    }
  }

  // Close modal function
  window.closeHVACModal = function() {
    const modal = document.getElementById('hvacExitModal');
    if (modal) {
      modal.classList.remove('active');
      modal.setAttribute('aria-hidden', 'true');

      // Track with GTM
      if (typeof dataLayer !== 'undefined') {
        dataLayer.push({
          event: 'exit_intent_modal_closed',
          page_url: window.location.href
        });
      }

      log('Modal closed');
    }
  };

  // Tracking functions
  window.trackModalPhoneClick = function() {
    if (typeof dataLayer !== 'undefined') {
      dataLayer.push({
        event: 'exit_modal_phone_click',
        event_category: 'conversion',
        event_label: 'phone_number',
        value: 15
      });
    }
    log('Phone click tracked');
  };

  window.trackModalContactClick = function() {
    if (typeof dataLayer !== 'undefined') {
      dataLayer.push({
        event: 'exit_modal_contact_click',
        event_category: 'conversion', 
        event_label: 'contact_form',
        value: 10
      });
    }
    log('Contact click tracked');
  };

  // Exit intent detection
  function setupExitIntent() {
    let exitIntentFired = false;

    document.addEventListener('mouseleave', function(e) {
      if (exitIntentFired || !config.exitIntent) return;
      
      if (e.clientY <= 0) {
        exitIntentFired = true;
        exitIntentTriggered = true;
        showModal('exit_intent');
      }
    });

    // Mobile exit intent (scroll to top quickly)
    let lastScrollTop = 0;
    window.addEventListener('scroll', function() {
      if (exitIntentFired || !config.exitIntent) return;

      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      
      if (scrollTop < lastScrollTop && lastScrollTop > 100 && scrollTop === 0) {
        exitIntentFired = true;
        exitIntentTriggered = true;
        showModal('mobile_exit_intent');
      }
      
      lastScrollTop = scrollTop;
    });
  }

  // Time-based trigger
  function setupTimeDelay() {
    if (config.timeDelay > 0) {
      setTimeout(() => {
        if (!modalShown) {
          timeDelayTriggered = true;
          showModal('time_delay');
        }
      }, config.timeDelay);
    }
  }

  // Scroll-based trigger
  function setupScrollTrigger() {
    if (config.scrollPercentage > 0) {
      window.addEventListener('scroll', function() {
        if (scrollTriggered) return;

        const scrolled = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
        
        if (scrolled >= config.scrollPercentage) {
          scrollTriggered = true;
          showModal('scroll_percentage');
        }
      });
    }
  }

  // Keyboard event handling
  function setupKeyboardEvents() {
    document.addEventListener('keydown', function(e) {
      const modal = document.getElementById('hvacExitModal');
      if (modal && modal.classList.contains('active')) {
        if (e.key === 'Escape') {
          closeHVACModal();
        }
      }
    });
  }

  // Click outside to close
  function setupClickOutside() {
    document.addEventListener('click', function(e) {
      const modal = document.getElementById('hvacExitModal');
      if (modal && modal.classList.contains('active')) {
        if (e.target === modal) {
          closeHVACModal();
        }
      }
    });
  }

  // Initialize when DOM is ready
  function init() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
      return;
    }

    log('Initializing exit intent modal');
    
    setupExitIntent();
    setupTimeDelay();
    setupScrollTrigger();
    setupKeyboardEvents();
    setupClickOutside();

    log('Exit intent modal initialized');
  }

  // Start initialization
  init();

  // Expose config for GTM customization
  window.HVACExitModalConfig = config;
  window.showHVACModal = showModal;

})();
</script>

<!-- GTM Integration Examples -->
<script>
/*
=== GOOGLE TAG MANAGER INTEGRATION EXAMPLES ===

1. BASIC EXIT INTENT TRIGGER:
Trigger Type: Custom Event
Event Name: exit_intent_modal_shown

2. CONVERSION TRACKING:
Track phone clicks and form submissions from modal

3. AUDIENCE BUILDING:
Create audiences based on modal interactions

4. A/B TESTING:
Test different modal variations

5. CUSTOM VARIABLES:
- {{Exit Modal Trigger}} = {{DLV - modal_trigger}}
- {{Page URL}} = {{DLV - page_url}}

=== DEPLOYMENT OPTIONS ===
*/
</script>

</body>
</html>